This is a half-bridge SiC module.
Since only metallic post-type connections are used, this is a wire-bondless architecture.
Since multiple device layers are stacked vertically, it is a 3D module.
There is a through cermaic via DBC and two other DBCs are stacked for double-sided cooling.
Kelvin source connection is not available.
This layout is used in ICCAD 2021:
	Imam Al Razi, Quang Le, H. Alan Mantooth, and Yarui Peng, “Hierarchical Layout Synthesis and Optimization Framework for High-Density Power Module Design Automation”, in Proc. International Conference on Computer-Aided Design, pp. 1-8, Nov 2021.
