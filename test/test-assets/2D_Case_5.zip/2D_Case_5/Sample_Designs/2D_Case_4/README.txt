This is a half-bridge module.
Since only bonding wires are used for both gate and power loop connections, this is a wire-bonded module.
Since single device layer is used, it is a 2D module.
Single-sided cooling
Kelvin source connection is available.
