This is a half-bidge SiC module.
Since only bonding wires are used for both gate and power loop connections, this is a wire-bonded module.
Since single device layer is used, it is a 2D module.
Single-sided cooling
Kelvin source connection is not available.
This layout is used in ECCE 2021:
Quang Le, Imam Al Razi, Yarui Peng, and H. Alan Mantooth, “Fast and Accurate Inductance Extraction For Power Module Layout Optimization Using Loop-Based Method”, in Proc. IEEE Energy Conversion Congress and Exposition, pp. 1358-1365, Oct 2021
