This is a half-bridge module.
Since only bonding wires are used for both gate and power loop connections, this is a wire-bonded module.
Since single device layer is used, it is a 2D module.
Single-sided cooling
Kelvin source connection is available.
This case has been used in :
Imam Al Razi, Quang Le, Tristan Evans, Shilpi Mukherjee, H. Alan Mantooth, and Yarui Peng, “PowerSynth Design Automation Flow for Hierarchical and Heterogeneous 2.5D Multi-Chip Power Modules”, IEEE Transactions on Power Electronics, vol. 36, no. 8, pp. 8919–8933, 2021
