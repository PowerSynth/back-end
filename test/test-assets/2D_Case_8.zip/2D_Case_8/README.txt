This is a half-bidge SiC module.
Since only bonding wires are used for power loop connections, this is a wire-bonded module.
Since single device layer is used, it is a 2D module.
Single-sided cooling (custom baseplate with very high heat transfer coefficient)
Kelvin source connection is not available.
There is no gate loop here. Gate signals are shifted to another PCB board. This layout is tried as a part of request from Packaging student Rana.